main.o: main.cc gamecontroller.h Structs/move.h Structs/piece.h \
 Structs/tile.h puzzle.h Structs/tile.h Graphics/textdisplay.h \
 GameLogic/chessboard.h Structs/piece.h subject.h observer.h observer.h \
 Graphics/graphicsdisplay.h GameLogic/boardmanager.h \
 GameLogic/chessboard.h Moves/movemaker.h GameLogic/gamestatechecker.h \
 Moves/movegenerator.h Moves/movemaker.h Graphics/window.h \
 Players/player.h
