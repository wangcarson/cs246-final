Structs/move.o: Structs/move.cc Structs/move.h Structs/piece.h \
 Structs/tile.h
