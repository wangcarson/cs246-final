Structs/piece.o: Structs/piece.cc Structs/piece.h
