#ifndef __TEXTDISPLAY_H__
#define __TEXTDISPLAY_H__
#include <vector>
#include <iostream>

#include "tile.h"
#include "chessboard.h"
#include "observer.h"

class TextDisplay: public Observer {
    ChessBoard &board;
    bool largeTD;
    std::vector<std::vector<char>> display; // stdout display

  public:
    TextDisplay(ChessBoard &b, bool largeTD);
    void notify(Tile t) override;
    void print(std::ostream &out) const;

    friend std::ostream &operator<<(std::ostream &out, const TextDisplay &s);
};

std::ostream &operator<<(std::ostream &out, const TextDisplay &s);

#endif
