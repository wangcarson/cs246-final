Graphics/textdisplay.o: Graphics/textdisplay.cc Graphics/textdisplay.h \
 Structs/tile.h GameLogic/chessboard.h Structs/piece.h subject.h \
 observer.h observer.h
