Graphics/window.o: Graphics/window.cc Graphics/window.h
