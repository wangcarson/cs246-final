puzzle.o: puzzle.cc puzzle.h Structs/tile.h Structs/move.h \
 Structs/piece.h Structs/tile.h
