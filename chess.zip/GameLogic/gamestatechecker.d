GameLogic/gamestatechecker.o: GameLogic/gamestatechecker.cc \
 GameLogic/gamestatechecker.h Structs/piece.h GameLogic/chessboard.h \
 Structs/tile.h subject.h observer.h Moves/movegenerator.h Structs/move.h \
 Structs/piece.h Structs/tile.h GameLogic/chessboard.h Moves/movemaker.h
