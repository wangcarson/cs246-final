GameLogic/chessboard.o: GameLogic/chessboard.cc GameLogic/chessboard.h \
 Structs/piece.h Structs/tile.h subject.h observer.h
