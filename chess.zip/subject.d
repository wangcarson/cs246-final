subject.o: subject.cc subject.h observer.h Structs/tile.h
