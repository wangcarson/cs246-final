structs.o: structs.cc structs.h
