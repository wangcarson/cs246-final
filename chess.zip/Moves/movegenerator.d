Moves/movegenerator.o: Moves/movegenerator.cc Moves/movegenerator.h \
 Structs/move.h Structs/piece.h Structs/tile.h Structs/tile.h \
 GameLogic/chessboard.h Structs/piece.h subject.h observer.h \
 Moves/movemaker.h
