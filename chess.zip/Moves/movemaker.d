Moves/movemaker.o: Moves/movemaker.cc Moves/movemaker.h Structs/move.h \
 Structs/piece.h Structs/tile.h Structs/tile.h GameLogic/chessboard.h \
 Structs/piece.h subject.h observer.h
