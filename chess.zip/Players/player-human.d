Players/player-human.o: Players/player-human.cc Players/player-human.h \
 Structs/piece.h Structs/move.h Structs/piece.h Structs/tile.h \
 Players/player.h
