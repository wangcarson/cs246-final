Players/evaluation.o: Players/evaluation.cc Players/evaluation.h \
 Structs/piece.h GameLogic/boardmanager.h GameLogic/chessboard.h \
 Structs/tile.h subject.h observer.h Moves/movemaker.h Structs/move.h \
 Structs/piece.h Structs/tile.h GameLogic/chessboard.h \
 GameLogic/gamestatechecker.h Moves/movegenerator.h Moves/movemaker.h
