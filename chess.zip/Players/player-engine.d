Players/player-engine.o: Players/player-engine.cc Players/player-engine.h \
 Structs/piece.h Structs/move.h Structs/piece.h Structs/tile.h \
 Players/player.h GameLogic/boardmanager.h GameLogic/chessboard.h \
 Structs/tile.h subject.h observer.h Moves/movemaker.h \
 GameLogic/chessboard.h GameLogic/gamestatechecker.h \
 Moves/movegenerator.h Moves/movemaker.h Players/evaluation.h
