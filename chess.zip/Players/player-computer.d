Players/player-computer.o: Players/player-computer.cc \
 Players/player-computer.h Structs/move.h Structs/piece.h Structs/tile.h \
 Players/player.h GameLogic/boardmanager.h GameLogic/chessboard.h \
 Structs/piece.h Structs/tile.h subject.h observer.h Moves/movemaker.h \
 GameLogic/chessboard.h GameLogic/gamestatechecker.h \
 Moves/movegenerator.h Moves/movemaker.h
