player.o: player.cc player.h structs.h boardmanager.h chessboard.h \
 subject.h observer.h movemaker.h gamestatechecker.h movegenerator.h
